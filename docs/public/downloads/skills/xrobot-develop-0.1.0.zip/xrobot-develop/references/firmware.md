# Firmware Operations

实机任务按本文执行。使用 `firmware/source/`、`firmware/build/`、`firmware/backup/`、`firmware/logs/`、`firmware/tools/` 和 `firmware/development.md`。已有工程原地保留，构建使用独立输出目录。

## 设备识别

1. 复用本地 Python、esptool 和串口工具；缺少时安装到任务工具环境。
2. 枚举串口，按 USB 信息和 MAC 选择设备。Windows 示例：

```powershell
python -m serial.tools.list_ports -v
Get-CimInstance Win32_SerialPort | Select-Object DeviceID, Description, PNPDeviceID
python -m esptool --port $devicePort flash-id
```

3. 对照所选源码版本的板级配置确认外设和引脚。缺少适配时列出差异，按已授权需求实现。
4. 设备重插时重新确认端口和 MAC；连接未变时复用识别结果。仅采集本次定位所需的启动日志，擦写前关闭本次串口监视器。

## 构建

1. 加载匹配版本的本地 ESP-IDF 或已有构建容器，保留缓存，按所选版本的官方入口增量构建目标板型。
2. 本地环境不适配时准备单板云端 workflow，使用已授权仓库和 ref，纳入本次修改与 OTA 配置后触发构建。远端目标或授权缺失时先准备代码与 workflow，再询问缺失项。
3. 构建失败先处理首个相关错误；代码错误在当前环境修复，环境错误按实际原因处理或更换环境。
4. 保存本次成功构建的应用、所需 bootloader/partition table/assets、sdkconfig 和 flash_args/flasher_args.json。云端产物从对应成功 run 下载到 `firmware/build/`。

## 备份

首次擦写非空白设备前执行一次整片备份，正常与故障固件均适用。已确认空白的设备直接初始化；状态未知时先备份。

```powershell
# 使用 firmware/backup/<MAC>/<timestamp>/ 下的新文件路径
python -m esptool --port $devicePort read-flash 0 ALL $backupPath
Get-FileHash -LiteralPath $backupPath -Algorithm SHA256
```

检查退出码、文件长度和 Flash 容量，记录 SHA256，完成工具支持的设备内容校验。校验通过后保存结果并复用备份；校验失败时排查后重读。设备更换、备份损坏或需要保存新状态时再备份。

读取失败时暂停擦写。加密或 Secure Boot 设备采用厂商对应流程，禁止强制绕过保护。

## 烧录与验证

1. 核对产物的芯片、板型、容量、实际分区地址及擦除范围，按 [esptool 文档](https://docs.espressif.com/projects/esptool/en/latest/) 生成适配当前工具版本的写入命令。
2. 按设备状态选择写入范围：

| 状态 | 写入要求 |
| --- | --- |
| 原固件可用 | 使用兼容布局，保留 NVS 和兼容资产，写入必要镜像并指定启动槽；要求保留数据时禁止全擦或整片覆盖 |
| 固件故障 | 按故障原因定向修复；初始化前列明数据覆盖范围，仅在恢复授权范围内执行 |
| 空白板 | 写入对应板型完整初始化镜像或镜像组合，包含必需资产；按实际布局处理 otadata |

3. 分区或资产格式变化时先确定数据迁移方案，再执行写入。
4. 完成写入校验并复位，检查启动结果和实际 OTA 地址。绑定缺失时提供 MAC 或激活码并交接用户；明确要求 API 绑定时执行设备接口。
5. 验证一轮对话及本次改动。显示、声音和按键等人工测试交给用户，记录返回结果。
6. 执行已授权回滚时使用同一设备的已校验备份；故障固件备份按原状态恢复。

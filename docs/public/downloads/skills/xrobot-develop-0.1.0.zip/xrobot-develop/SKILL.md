---
name: xrobot-develop
description: 开发和接入 xrobot（灵矽AI）的硬件固件、软件客户端、平台 API 与 MCP 工具。用于源码准备、功能定制、本地或云端编译、备份烧录、设备接入及平台资源配置；官网交互交由用户完成。
---

# XRobot Develop

## 任务选择

从请求和现有工程确定目标、输入及交付阶段。复用已确认信息，只补问阻塞下一步的必要输入。按下表选择流程，组合任务按依赖顺序执行。

| 目标 | 流程 | 必要输入 |
| --- | --- | --- |
| 源码准备、固件定制、编译或烧录 | 硬件固件 | 板型或待识别设备、已有源码位置、目标功能 |
| 桌面或网页语音客户端 | 软件客户端 | 运行平台、语言、已有工程、目标功能 |
| 管理智能体、设备、模型、知识库、音色等资源 | 平台 API | 本地凭证位置、目标资源、具体操作 |
| 执行客户端动作或调用业务服务 | MCP 工具 | 工具功能、执行位置、目标智能体 |

仅请求源码时交付源码、版本和修改入口；仅请求构建时交付产物；请求烧录时执行备份与写入；请求平台接入时完成绑定及会话验证。

## 执行约定

- 复用现有工程和依赖，保留未提交改动。新软件工程使用当前目录下的 `xrobot-develop/`，硬件任务使用 `firmware/`。自建目录及文件统一用英文：`source/`、`build/`、`backup/`、`logs/`、`tools/`、`development.md`；保留上游要求的原始名称。
- 按需读取官方文档，同一任务复用已读内容。Guide 用于操作步骤，API 和协议页用于请求字段；替换示例地址、ID 和凭证占位符。
- 优先本地增量构建，保留缓存。复用设备信息与已校验原始备份；设备更换时重新识别，备份损坏或需要保存新状态时重新备份。
- 使用环境变量或本地私有配置读取凭证，禁止将密钥写入代码、提交或日志。仅执行已授权的外部写操作，已有授权不重复确认。
- 按目标功能执行定向验证。出现新改动、新失败或未解决问题时再补充检查。

## 官网操作交接

将登录、扫码、授权、创建 API Key、官网绑定、页面配置和网页体验交给用户。提供当前缺失项对应的入口、操作和返回信息；不代替用户操作控制台。暂停依赖这些信息的步骤，继续独立开发工作。

| 缺失项 | 向用户提供的操作 | 获取的结果 |
| --- | --- | --- |
| 账号或智能体 | 登录 [控制台](https://xrobo.qiniu.com/)，按 [快速入门](https://linx.qiniu.com/docs/xrobot/guide/quick-start) 创建或选择智能体 | 智能体 ID |
| API 凭证 | 按 [认证说明](https://linx.qiniu.com/docs/xrobot/api/) 创建 API Key 并配置到本地 | 环境变量名或私有配置路径；不索取聊天中的密钥明文 |
| 角色、模型、音色或 MCP 配置 | 按 [智能体配置指引](https://linx.qiniu.com/docs/xrobot/guide/agent-config) 配置、保存并重连；MCP 开通见 [市场指南](https://linx.qiniu.com/docs/xrobot/mcp/mcp-store) | 资源 ID 和已完成配置 |
| 配网或设备绑定 | 提供已读取的 MAC 或激活码，指向 [绑定指南](https://linx.qiniu.com/docs/xrobot/guide/xiaozhi-firmware) 或 [手机配网指南](https://linx.qiniu.com/docs/xrobot/guide/xiaozhi-hardware) | 绑定状态及智能体 ID |
| 网页验证 | 按 [网页体验指引](https://linx.qiniu.com/docs/xrobot/guide/agent-config) 授权麦克风并测试；提示拨打会保存当前表单 | 识别、回答和声音的实测结果 |

用户明确要求通过 API 创建、配置或绑定资源时，执行平台 API 流程。获得交接结果后从暂停步骤继续。

## 硬件固件

1. **识别。** 枚举 USB 串口，读取芯片、MAC、Flash 和可用启动日志，结合实物型号确定板型。无串口时要求连接 USB 数据线并暂停实机流程；明确要求离线准备且板型已知时继续离线阶段。板型未确定时询问型号。
2. **准备源码。** 检查已有工程及改动，复用匹配源码；否则在 `firmware/source/` 获取 [xiaozhi-esp32](https://github.com/78/xiaozhi-esp32)，固定支持目标板型的 tag/commit。按该版本的 [板级说明](https://github.com/78/xiaozhi-esp32/blob/main/docs/custom-board.md) 选择 board/variant，记录源码路径、版本与修改入口。
3. **实现。** 按需求修改功能，按 [OTA 协议](https://linx.qiniu.com/docs/xrobot/platform/OTA) 配置 xrobot 接入。检查持久化 OTA 设置与编译默认值的优先级，确认目标地址生效。
4. **编译。** 加载匹配版本的本地 ESP-IDF 或已有构建容器，只构建目标板型。无合适本地环境时使用已授权的云端 CI，纳入本次代码和 OTA 配置，记录成功构建的 commit/run 与产物。
5. **备份与烧录。** 读取 [硬件操作细则](references/firmware.md)。首次擦写非空白设备前备份并校验，连续调试复用原始备份；按实际分区和构建参数写入，空白板使用完整初始化产物。
6. **验证。** 检查启动、配网、绑定和 OTA 返回的连接配置，完成一轮对话及定制功能验证。绑定缺失时执行官网操作交接；明确要求 API 绑定时执行平台 API 流程。

## 软件客户端

1. **准备工程。** 确定平台和语言，复用已有代码；Linux/macOS 按需使用 [客户端 Demo](https://linx.qiniu.com/docs/xrobot/guide/client-demo)。持久保存 `Device-Id`、`Client-Id`；网页连接需要自定义鉴权 Header 时使用后端代理。
2. **接入。** 按 [OTA 协议](https://linx.qiniu.com/docs/xrobot/platform/OTA) 上报身份与版本。需要绑定时交接激活码，绑定完成后获取连接地址与设备会话 Token；会话连接使用设备 Token，平台管理使用 API Key。
3. **建立会话。** 按 [WebSocket 协议](https://linx.qiniu.com/docs/xrobot/platform/websocket) 实现握手、hello、listen、音频发送及响应播放。新语音原型优先使用 PCM，已有工程沿用其音频方案，参数遵循服务端协商结果。
4. **实现交互。** 按需求增加 UI、文本输入、打断或 [智能体与音色切换](https://linx.qiniu.com/docs/xrobot/platform/agent-voice-switch)。本机动作按端侧 MCP 流程实现。
5. **验证。** 完成一轮真实输入与响应，核对本次交互；语音功能检查麦克风输入和扬声器播放，人工测试项交给用户并记录结果。

## 平台 API

1. **认证。** 从本地配置读取灵矽 API Key，按 [API 总览](https://linx.qiniu.com/docs/xrobot/api/) 设置 `Authorization: Bearer <api_key>`。凭证缺失时执行官网操作交接。
2. **定位资源。** 查询列表或详情，获取目标 ID，复用已有资源。
3. **执行。** 按下表读取所需接口，使用其方法、路径和请求体执行已授权操作；检查 HTTP 状态与业务响应码，记录返回 ID。
4. **验证。** 查询变更后的资源；影响会话或工具的配置，重新连接目标客户端并验证效果。

| 能力 | 接口文档 |
| --- | --- |
| 智能体、人设和关联配置 | [智能体](https://linx.qiniu.com/docs/xrobot/api/agent) |
| 模型配置及参数 | [模型](https://linx.qiniu.com/docs/xrobot/api/llm) |
| 设备绑定、预注册和查询 | [设备](https://linx.qiniu.com/docs/xrobot/api/device) |
| 文档、检索和关联 | [知识库](https://linx.qiniu.com/docs/xrobot/api/knowledge) |
| 音色训练与管理 | [音色](https://linx.qiniu.com/docs/xrobot/api/voice-clone) |
| 记忆、记录和声纹 | [长期记忆](https://linx.qiniu.com/docs/xrobot/api/longterm-memory)、[聊天记录](https://linx.qiniu.com/docs/xrobot/api/chat-history)、[声纹](https://linx.qiniu.com/docs/xrobot/api/voiceprint-v2) |
| 固件版本记录和文件 URL | [固件管理](https://linx.qiniu.com/docs/xrobot/api/firmware) |

## MCP 工具

### 端侧工具

适用于固件动作和软件客户端本机动作。

1. 定义工具名称、描述、参数和执行函数。
2. 按 [端侧 MCP](https://linx.qiniu.com/docs/xrobot/mcp/hardware-mcp) 注册工具，实现 initialize、tools/list、tools/call，在 hello 中声明 MCP 能力。
3. 固件工具构建烧录后连接，软件工具直接启动客户端；确认平台发现目标工具。
4. 触发一次真实调用，核对动作及返回结果。

### 云端工具

适用于平台通过网络调用的业务服务。

1. 使用现有服务时，按 [MCP 市场](https://linx.qiniu.com/docs/xrobot/mcp/mcp-store) 开通配置实例；自建服务时，按 [云端 MCP](https://linx.qiniu.com/docs/xrobot/mcp/software-mcp) 实现并本地验证 tools/list、tools/call。
2. 自建服务提供平台可达的 HTTPS Streamable HTTP 地址，按 [自定义 MCP](https://linx.qiniu.com/docs/xrobot/mcp/custom-mcp) 注册和配置，复用已授权部署环境。
3. 将账号下的配置实例关联到目标智能体，配置所需业务凭证。官网操作交接给用户；明确要求 API 操作时执行对应接口。
4. 用目标客户端触发调用，核对业务执行结果和助手响应。

## 按需参考

| 功能 | 操作指南 |
| --- | --- |
| 接入自有模型服务 | [自定义 LLM](https://linx.qiniu.com/docs/xrobot/guide/third-app) |
| 创建、解析、检索和关联知识文档 | [知识库实践](https://linx.qiniu.com/docs/xrobot/guide/knowledge-start) |
| 配置记忆容器与变量 | [长期记忆实践](https://linx.qiniu.com/docs/xrobot/guide/longterm-memory-start) |
| 拍照与视觉分析 | [拍照功能](https://linx.qiniu.com/docs/xrobot/guide/camera-feature)；使用 MCP initialize 下发的视觉地址与 Token |
| 品牌小程序及后台 | [小程序与后台方案](https://linx.qiniu.com/docs/xrobot/guide/platform-mp) |
| 查找其他操作 | [Guide 目录](https://linx.qiniu.com/docs/xrobot/guide/)、[MCP 目录](https://linx.qiniu.com/docs/xrobot/mcp/) |

## 交付要求

返回本次变更、源码或产物路径、关键资源 ID、运行方式及验证结果。区分已完成验证与待用户执行的项目；有阻塞时列出具体缺失输入。保留源码、备份、产物和必要日志，删除无用临时文件。
